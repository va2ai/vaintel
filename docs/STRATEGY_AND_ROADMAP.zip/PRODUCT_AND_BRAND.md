# V2 Product and Brand

This file is the source of truth for V2 brand identity, positioning, navigation, product catalog, and tier model.

Use it for: homepage messaging, navigation labels, footer language, CTA language, pricing page structure, tool catalog pages, upgrade messaging, landing page packaging, and roadmap prioritization.

## 1. Brand Architecture

### Company / parent brand

Veteran 2 Veteran

### Short product mark

V2

### Product category

VA claims intelligence

### Product description

Veteran 2 Veteran is a VA claims intelligence platform combining independent reporting, legal research tools, and claim strategy workflows for veterans, advocates, and attorneys.

### Short description

Independent reporting and claims intelligence for VA disability claims and appeals.

### Product stack framing

V2 should be explained as one platform with four layers:

- Publication
- Free Research Tools
- Premium Claim Tools
- Internal Research and Editorial Systems

## 2. Positioning Rules

### Lead with

- independent reporting
- claims intelligence
- legal and policy research
- claim strategy workflows
- trusted tools for veterans, advocates, and attorneys

### Use "AI" carefully

AI should support the message, not lead it.

Preferred:

- AI-assisted research
- AI-powered claim strategy workflows
- AI tools grounded in legal and policy sources

Avoid as primary positioning:

- generic AI assistant
- AI for everything
- chatbot-first framing

Reason: The trust story should come from rigor, sourcing, and domain specialization, not generic AI language.

## 3. Canonical Messaging

### Primary homepage headline

VA Claims Intelligence

### Primary homepage subhead

Independent reporting and claims intelligence for VA disability claims, appeals, and case strategy.

### Expanded platform statement

Veteran 2 Veteran combines an authoritative publication, research tools, and premium claim-analysis workflows into one VA claims intelligence platform.

### Trust statement

Grounded in BVA decisions, CFR, KnowVA, and CAVC research. Not legal advice. Not affiliated with the VA.

## 4. Audience Language

### Veterans

Use: understand your claim, strengthen your evidence, understand a denial, learn the rules, build a stronger filing strategy

### Advocates / VSOs / accredited agents

Use: accelerate research, find patterns faster, build evidence checklists, support claims strategy

### Attorneys

Use: accelerate appellate research, analyze decisions faster, structure issue-by-issue strategy, support legal memo workflows

## 5. CTA Language

### Primary CTAs

- Start Research
- Explore Tools
- Read Latest
- Get the Weekly Brief

### Secondary CTAs

- Search Decisions
- Browse Policy
- Read Case Analysis
- Explore Claim Strategy

### Avoid

- Try AI
- Chat Now
- Ask Anything

Those CTAs are too generic and weaken the category positioning.

## 6. Naming Rules

### Preferred umbrella labels

- Publication
- Free Research Tools
- Premium Claim Tools
- Weekly Brief
- Case Analysis
- Claims Strategy
- Policy

### Avoid vague labels

- Research
- AI Assistant
- Copilot
- Smart Search

Use more concrete job-based or domain-based names instead.

## 7. Official Navigation

### Utility bar

- Weekly Brief
- About
- Search

### Main nav

- Home
- Policy
- Claims Strategy
- Case Analysis
- Decision Search
- Tools

## 8. Route Mapping

- Home: `/`
- Policy: `/section/va-policy`
- Claims Strategy: `/section/claims-strategy`
- Case Analysis: `/section/cavc`
- Decision Search: `/bva`
- Tools: `/tools`

### Navigation design notes

- "Policy" instead of "Latest VA Policy" — cleaner and more reusable as a nav label. Section headers can still say "Latest VA Policy."
- "Decision Search" instead of "Research" — too vague. "Decision Search" tells the user what the route does.
- "Tools" instead of "Research Tools" — keeps main nav compact. The page itself clarifies these are research and claim tools.

## 9. Footer

### Footer tagline

Independent reporting and claims intelligence for VA disability claims, appeals, and advocacy.

### Footer sections

- Publication
- Tools
- Company

## 10. Tier Model

The official pricing ladder is:

- Free
- Pro
- Professional

Do not introduce more tiers until this model is clear and live.

### Packaging principle

V2 should sell workflows, not raw technical features. The user should understand each offer in terms of what job it does: understand my claim, research similar decisions, find the governing rule, build a stronger strategy, analyze a denial, accelerate professional research.

## 11. Free Tier

### Positioning

Free gives users access to the publication and entry-point research utilities. This tier should build trust, recurring usage, and newsletter conversion.

### Intended audience

- veterans
- family members helping with a claim
- first-time visitors
- casual researchers
- top-of-funnel advocates

### Included products

**Publication:** all articles, all guides, all news / policy updates, newsletter signup

**Research utilities:**

- BVA Decision Search
- 38 CFR Navigator
- KnowVA / M21-1 Search
- VA Math Calculator
- CAVC Precedent Library

**Entry-level claim tool:**

- Nexus Scout Lite (primary-to-secondary condition exploration, downloadable public evidence packs, limited guided research prompts — no deep claim-specific analysis or persistent workspace)

### Free tier purpose

Free is the trust and acquisition layer, not the main monetization layer. Maximize trust, SEO, discoverability, and newsletter conversion. Do not constrain it so much that the product feels unusable.

## 12. Pro Tier

### Positioning

Pro is for serious self-directed claim research and strategy building — deeper outputs, more guided workflows, and repeated usage.

### Intended audience

- veterans actively working a claim
- veterans preparing supplemental claims or HLRs
- power users who need more than search
- some advocates working solo

### Included products

- **Claim Research Assistant** — cross-source claim research workflow grounded in BVA, CFR, KnowVA, and CAVC materials. Faster issue research, better evidence framing, stronger claim strategy direction.
- **Nexus Scout Pro** — expanded version with stronger evidence mapping, richer secondary-claim reasoning, claim-building suggestions, deeper supporting research paths.
- **CAVC Case Analyzer** — structured breakdowns of CAVC decisions: holding, reasoning, practical significance, claims-strategy implications.
- Deeper guided citation-backed research outputs
- Saved research sessions
- Longer and richer synthesis outputs
- Exportable research packets

### Pro boundary rules

Pro can include: individual research acceleration, stronger summaries, deeper issue analysis, citation-backed outputs.

Pro should not include: advanced denial deconstruction as a flagship workflow, attorney-oriented matter workflows, highest-usage professional capacity.

Pro should feel clearly stronger than Free, but not so legal-professional that it confuses the market.

## 13. Professional Tier

### Positioning

Professional is for advocates, accredited agents, and attorneys who need deeper document analysis and more robust legal research workflows.

### Intended audience

- accredited representatives
- VSOs / advocates with heavier usage
- attorneys
- appellate practitioners

### Included products

- **Decision Deconstructor** — the flagship proprietary workflow. Upload a VA decision or denial -> favorable findings, denial basis, issue-by-issue breakdown, missing evidence, likely next filing lane, related legal and case support.
- **Appeal Strategy Workbench** — issue mapping, appeal-oriented research, evidence gap review, structured next-step strategy.
- **Attorney Research Mode** — faster appellate research, more complex issue sets, denser source handling, higher-confidence legal workflow support.
- Advanced CAVC deep-dive workflows
- Higher usage limits
- Professional-grade export/report outputs

### Professional boundary rules

Professional is where the heaviest-value and highest-trust workflows should live: denial analysis, appeal strategy, professional research acceleration, highest-usage product access. It should feel like a true category step-up, not just "Pro with more credits."

## 14. Tier Summary

| Tier | Core promise | Main audience | Key products |
|---|---|---|---|
| Free | Learn the rules and start researching | Veterans and top-of-funnel users | Publication, BVA Decision Search, 38 CFR Navigator, KnowVA Search, VA Math Calculator, CAVC Precedent Library, Nexus Scout Lite |
| Pro | Build stronger claim strategy with deeper guided research | Serious self-directed claimants | Claim Research Assistant, Nexus Scout Pro, CAVC Case Analyzer, saved research, exports |
| Professional | Analyze denials and accelerate professional-grade workflows | Advocates, agents, attorneys | Decision Deconstructor, Appeal Strategy Workbench, Attorney Research Mode |

## 15. Upgrade Logic

### Free -> Pro

Message: Move from search and reading into guided claim strategy.

Trigger: user wants deeper issue analysis, stronger synthesis, saved work, research exports, repeated workflow use.

### Pro -> Professional

Message: Move from self-directed claim research into professional-grade document analysis and appeal workflows.

Trigger: user wants denial analysis, issue-by-issue breakdowns, appeal workflows, heavier usage, more professional reporting.

## 16. Homepage Structure

Recommended section order:

1. Brand statement / masthead
2. Hero story and latest intelligence
3. Policy
4. Case Analysis
5. Claims Strategy
6. Research Guides / explainers
7. Tools
8. Weekly Brief signup

## 17. Implementation Rule

Whenever a new page, feature, or CTA is added, it should answer:

- Is this publication, a free research tool, a premium tool, or an internal workflow?
- Does the label describe the user job clearly?
- Does the copy strengthen "VA claims intelligence" as the category story?
- Is this Free, Pro, or Professional?
- What user job does it solve?
- Is it a search utility, a strategy workflow, or a document-analysis workflow?

If the answer is unclear, rename or reframe before shipping.
