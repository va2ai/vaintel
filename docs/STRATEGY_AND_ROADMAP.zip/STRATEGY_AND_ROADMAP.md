# V2 Strategy and Roadmap

This file defines the long-term strategy, execution matrix, and build priorities for V2.

Companion doc: [PRODUCT_AND_BRAND.md](./PRODUCT_AND_BRAND.md) (brand, nav, catalog, tiers)

## 1. Core Strategic Shift

V2 is not starting from zero. The hardest technical layer already exists: multi-agent orchestration, streaming UX, domain retrieval across BVA/CFR/KnowVA/CAVC, a content site, admin surfaces, and multiple audience-specific landing pages.

The strategic shift is:

**From:** build the platform
**To:** productize what exists, unify the product story, publish consistently, package clear offerings, monetize with trust

The main remaining work is: brand unification, editorial systemization, research-to-publication workflows, product packaging, monetization gates, trust and conversion systems.

## 2. Product Thesis

V2 should become a VA claims intelligence platform that combines:

- an authoritative publication
- free public research tools
- premium claim-analysis workflows
- internal editorial and research automation

The strongest wedge products are module-driven, especially Decision Deconstructor. The long-term platform should be understandable as a set of connected workflows, not disconnected tools.

### Architecture module anchors

- Decision Deconstructor
- Interpretive Engine
- Secondary Mapper
- Nexus Scorer
- Terminology & Framing Engine

Productization should happen around modules and workflows, not around generic assistant framing.

## 3. What Already Exists

### Research Core

- multi-agent research orchestration
- structured retrieval across legal and policy sources
- claim and reference synthesis
- streaming product UX
- knowledge-base and theory distillation
- cite and deep-dive workflows
- observability and session state

### Publication Layer

- separate content site with guides, posts, and news
- admin dashboard with markdown editing
- image upload and Firestore-backed content management

### Tool Layer

- BVA search, CFR lookup, KnowVA / M21-1 search
- CAVC deep dive, Cite interface, Nexus Scout
- AI chat / assistant surfaces
- attorney-oriented pipeline

### Market Surface

- multiple landing pages
- audience-specific messaging directions
- freemium / premium product hints

## 4. Execution Matrix

| Area | Already Built | Needs Refinement | New Build | Nice Later |
|---|---|---|---|---|
| Brand consolidation | Multiple surfaces exist. Canonical brand language defined in PRODUCT_AND_BRAND.md. | Shared CTA language across surfaces, consistent subheads, product naming cleanup, design-system consistency | Deeper master messaging framework for every landing/product page | Full codebase consolidation if separate services remain workable |
| Information architecture | Site pages, tool surfaces, multiple entry points. Official nav implemented. | Tab sprawl reduction, route clarity, mapping features into free/pro/professional buckets, footer consistency | Canonical sitemap across all product surfaces, product map for tiers | Advanced personalization of nav by audience |
| Publication system | Content site, guides, posts, news, admin CRUD, markdown editing, images, Firestore-backed content | Editorial taxonomy cleanup, better templates, stronger article metadata, internal linking, topic hubs | Editorial standards page, methodology page, AI use policy, author system, newsletter archive | Multi-author CMS workflows and contributor management |
| Research core | Multi-agent orchestration, retrieval stack, streaming UX, synthesis modes, research graph, observability | Internal naming cleanup so this reads as one "Research Core" | Unified internal research packet schema for downstream editorial and premium tools | Additional agent complexity beyond current proven workflows |
| Research-to-publishing pipeline | Research sessions, structured outputs, citations, synthesis, case/reg retrieval | Output normalization for editorial use, source bundling, article-ready summaries | "Create Article From Research" flow, research packet to draft pipeline, editor approval queue | Fully automated no-human publishing |
| Editorial style system | Prompt infrastructure, role-based agents, structured synthesis | Tone consistency, headline quality, citation formatting, risk phrasing | Master style guide config, article-type rules, CTA rules, audience-specific variants | Per-author style emulation |
| Publish QA and verification | Citations, source retrieval, observability, structured outputs, legal source coverage | Basic validation layers, publish review ergonomics, confidence framing | Publish QA scorecard, unsupported-claim detector, citation validation, date verification, privacy/PII checks, legal-advice risk checks | Heavier automatic fact-checking across broader web/news |
| Free public tools | BVA search, CFR lookup, KnowVA search, CAVC exploration, Nexus Scout, content explainers | Rename tools around user jobs, simplify cards and entry points, improve descriptions | Tool catalog page with clear free/public positioning | More utility tools beyond the core set |
| Premium tools | Claim research workflows, CAVC deep dive, attorney pipeline, richer synthesis modes | Product packaging, pricing boundaries, value communication, upgrade prompts | Formal premium catalog, metering, saved research, export/report layers | Advanced workspace features before core monetization is proven |
| Decision Deconstructor | Important backend ingredients exist: document analysis, structured synthesis, claim workflows | Some plumbing exists but not as a single clean hero workflow | Dedicated upload-to-analysis product flow, favorable findings extraction, denial basis mapping, next-step strategy output | Secondary analysis products before this flagship launches |
| Audience segmentation | Attorney-specific and veteran-oriented surface directions exist | Messaging by audience, clearer paths for veterans vs VSOs vs attorneys, CTA targeting | Official audience tracks and audience-specific landing/product pages | Dynamic account-based tailoring by organization type |
| Monetization | Freemium direction, separate tool ideas, audience split exist | Cleaner packaging, fewer partial concepts, clearer upgrade paths | Free / Pro / Professional pricing model, entitlement boundaries, usage limits, export gating | Team billing, seats, collaborative workspaces |
| Newsletter and distribution | Publication supports newsletter CTAs and content cadence | Better placement, archive visibility, stronger subscriber journey | Daily/weekly digest pipeline, topic-based editorial distribution, retention loop | Sophisticated lifecycle automation and CRM segmentation |
| Automation control center | Observability, task flows, orchestration, session state, knowledge layers exist | Unify around editorial operations rather than leaving as backend capabilities | Source watchlists, story queue, draft queue, QA queue, scheduled briefs, publish calendar | Full newsroom-scale planning and staffing abstractions |
| Admin and internal ops | Admin editing surfaces for posts, guides, and news | Better workflow visibility, review states, editorial queueing, publish states | Internal workflow console for draft review, QA approval, publish scheduling | Deep role/permission modeling for larger teams |

## 5. Build Phases

### Phase 1: Clarify

**Status:** Brand language, official nav, and product catalog are completed.

**Do next:** Define editorial taxonomy. Define the product story in one sentence and one homepage structure.

**Avoid:** Building new tools before naming and packaging existing ones.

### Phase 2: Unify

**Do next:** Unify homepage messaging, site and app CTA paths, design language. Cross-link content and tools. Reduce route and tab sprawl.

**Avoid:** Launching more disconnected surfaces.

### Phase 3: Operationalize

**Do next:** Create research packet format, style guide system, draft -> QA -> editor workflow, publish queue.

**Avoid:** Fully automated publishing without strong review gates.

### Phase 4: Productize

**Do next:** Package public tools, package premium tools, launch Decision Deconstructor, define pricing and usage boundaries.

**Avoid:** Overbuilding team features before solo user monetization is clear.

### Phase 5: Scale

**Do later:** Daily brief, weekly digest, story detection automation, professional workflow expansion, team collaboration features.

## 6. Priority Stack

### Priority 1

- Editorial taxonomy and templates
- Tool catalog UI and pricing-page packaging
- Pricing and upgrade-path presentation

### Priority 2

- Research packet -> article workflow
- Editorial style guide engine
- Publish QA scorecard

### Priority 3

- Tool catalog packaging
- Free/pro/professional monetization boundaries
- Decision Deconstructor launch

### Priority 4

- Newsletter and digest automation
- Editorial operations console

## 7. Long-Term Build Sections

### Publication System Productization

Turn the content site into a real VA intelligence publication: formal editorial taxonomy, article templates by type, author pages, editorial standards page, AI use and sourcing policy, methodology pages, internal linking blocks, topic hub pages, newsletter archive.

Core editorial categories: VA Policy, Claims Strategy, Case Analysis, Research & Explainers, Tools & Guides.

### Research-to-Publishing Pipeline

Turn the research engine into a story-generation and briefing engine with human approval: Create Article From Research workflow, research packet schema, publishable source bundle, article-type selector, timeline generation, "what changed" summaries, headline and dek suggestions, structured draft output, editor review queue, publish approval gate.

### Editorial Style Guide Engine

Make AI-assisted output sound like V2: master editorial style guide in JSON or YAML, voice rules, headline conventions, citation conventions, "why it matters" block rules, prohibited phrases, claim-risk phrasing, no-legal-advice phrasing, audience-specific variants, CTA placement rules.

### Verification and Publish QA

Publication-grade QA gate: publish QA scorecard, unsupported-claim detection, citation completeness checks, date verification, regulation and case citation validation, title/body mismatch detection, privacy and PII detection, legal-advice risk detection, source-confidence labels.

### Decision Deconstructor (Flagship Wedge)

Upload VA decision -> extract favorable findings -> identify denial basis -> recommend next-step path. Outputs: favorable findings, missing evidence, likely filing lane, issue-by-issue strategy summary, related BVA/CAVC/CFR support.

### Audience-Specific Product Tracks

- **Veterans:** explainers, claim guides, calculators, lightweight tools, newsletter
- **VSOs / accredited agents:** research workflows, case search, pattern finding, evidence checklists, saved research
- **Attorneys:** appeal tools, deep-dive workflows, case clustering, professional memos, later team workflows

### Automation Control Center

Internal newsroom and operations console: source watchlists, topic alerts, candidate story queue, dossier generation, draft queue, QA queue, scheduled briefs, daily or weekly digests, publish calendar, performance feedback loop.

## 8. Decision Filters

### Green-light work if it:

- makes the product story clearer
- reduces fragmentation
- improves trust
- improves conversion into recurring usage
- strengthens a defensible product wedge

### Delay work if it:

- adds more disconnected surfaces
- showcases technical complexity without product gain
- duplicates existing capabilities under a new name
- expands architecture before packaging is solved

## 9. What Not To Rebuild

Do not spend early cycles rebuilding: another generic chatbot, another raw research tab, another generic multi-agent demo, another family of landing pages, more portfolio-first surfaces, a new backend architecture from scratch.

The infrastructure is already strong enough. The leverage is now in product discipline.

## 10. Operating Principle

The roadmap is now: **consolidate -> publish -> package -> monetize -> deepen moat**

The engine exists. The next stage is making it feel like a coherent category product instead of several strong systems living side by side.

## 11. Consolidated Product Structure

```text
V2
├── Publication
│   ├── VA Policy
│   ├── Claims Strategy
│   ├── Case Analysis
│   ├── Research & Explainers
│   └── Newsletter
│
├── Free Research Tools
│   ├── BVA Search
│   ├── CFR Navigator
│   ├── KnowVA Search
│   ├── VA Math Calculator
│   ├── CAVC Precedent Library
│   └── Nexus Scout Lite
│
├── Pro Claim Tools
│   ├── Claim Research Assistant
│   ├── Nexus Scout Pro
│   ├── CAVC Case Analyzer
│   └── Research Packet Export
│
├── Professional Claim Tools
│   ├── Decision Deconstructor
│   ├── Appeal Strategy Workbench
│   └── Attorney Research Mode
│
└── Internal Systems
    ├── Research Core
    ├── Editorial Automation
    ├── QA / Verification
    └── Admin / Analytics
```

## 12. What To Merge vs. Keep Separate

### Merge conceptually (should feel like one system)

- content site, research tools, premium AI workflows, newsletter, editorial automation, admin and review flows

### Keep separate technically if helpful

- site, research backend, premium tool app, admin tooling

The priority is experience consolidation, not immediate repo consolidation.
